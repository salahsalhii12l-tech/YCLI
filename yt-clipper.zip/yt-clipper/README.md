# YouTube Auto-Clipper

A personal-use tool: paste a YouTube link, it downloads the video, auto-detects scene
changes with ffmpeg, cuts it into clips, and lets you download individual clips or
everything as one ZIP.

⚠️ **Personal use only.** Downloading YouTube content may violate YouTube's Terms of
Service depending on how you use it. This tool is intended for private/personal use —
don't deploy it as a public service without checking the legal implications for your
use case.

## Requirements

- Python 3.9+
- `ffmpeg` and `ffprobe` (usually bundled together)
- Internet access

## Setup

```bash
chmod +x setup.sh
./setup.sh
```

This installs `ffmpeg` (if missing), creates a virtual environment, and installs
Python dependencies (including `yt-dlp`).

## Run

```bash
source venv/bin/activate
uvicorn main:app --reload --port 8000
```

Then open **http://localhost:8000** in your browser.

## How to use

1. Paste a YouTube URL into the box.
2. (Optional) Open "Advanced settings" to tune:
   - **Scene sensitivity** — lower value = more clips detected (more sensitive to
     small visual changes). Default `0.35` is a good middle ground.
   - **Min clip length** — clips shorter than this get merged into neighbors.
   - **Max clip length** — clips longer than this get force-split.
3. Click **Process Video**. It will download the video, analyze it, and cut clips —
   this can take a while for longer videos.
4. Once done, download individual clips or click **Download All (ZIP)**.

## How it works

1. **Download** — `yt-dlp` fetches the video as mp4 (up to 1080p).
2. **Scene detection** — `ffmpeg`'s `select='gt(scene,THRESHOLD)'` filter flags
   timestamps where the visual content changes significantly.
3. **Range building** — timestamps are turned into (start, end) clip ranges; ranges
   that are too short get merged into neighbors, and ranges that are too long get
   force-split evenly.
4. **Cutting** — each range is re-encoded with `ffmpeg` (`libx264` + `aac`) for
   frame-accurate cuts.
5. **Serving** — clips are saved under `clips/<job_id>/` and served via FastAPI;
   "Download All" zips them on the fly.

## Notes & tuning tips

- **Scene detection works best on visually varied content** (vlogs, gameplay,
  tutorials with slide changes). For podcasts or interviews with a mostly static
  frame, scene detection will produce very few cuts — you'd want silence-based
  detection instead (see "Extending" below).
- Re-encoding (`cut_clip` in `main.py`) is slower than stream-copying but guarantees
  clips start/end exactly where you expect. If speed matters more than precision,
  you can switch to `-c copy` in `cut_clip()` — cuts will snap to the nearest
  keyframe instead.
- Jobs and clips are **not automatically deleted**. Since this is for personal use,
  clean up the `clips/` folder manually when you don't need old outputs, or add a
  cron job / cleanup script if you want automation.

## Extending it

- **Silence-based detection**: swap `detect_scene_timestamps()` for an
  `ffmpeg -af silencedetect=noise=-30dB:d=0.5` based parser — useful for
  talking-head content where scene detection won't find much.
- **Thumbnails per clip**: run `ffmpeg -ss <mid_time> -i clip.mp4 -frames:v 1 thumb.jpg`
  after cutting each clip, and return thumbnail URLs alongside clip metadata.
- **Auth/rate limiting**: not included since this is single-user/local — add if you
  ever expose this beyond your own machine.

## Project structure

```
yt-clipper/
├── main.py              # FastAPI backend — download, detect, cut, serve
├── static/
│   └── index.html        # Frontend UI (single file, vanilla JS)
├── requirements.txt      # Python dependencies
├── setup.sh              # One-time environment setup
├── clips/                # Output folder (created automatically)
└── README.md
```
