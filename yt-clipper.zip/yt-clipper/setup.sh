#!/usr/bin/env bash
# One-time setup for the YouTube Auto-Clipper.
# Tested on Ubuntu/Debian. Adjust package manager lines for other OSes.

set -e

echo "=== YouTube Auto-Clipper Setup ==="

# 1. System dependency: ffmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo "Installing ffmpeg..."
    if command -v apt-get &> /dev/null; then
        sudo apt-get update && sudo apt-get install -y ffmpeg
    elif command -v brew &> /dev/null; then
        brew install ffmpeg
    else
        echo "Please install ffmpeg manually: https://ffmpeg.org/download.html"
        exit 1
    fi
else
    echo "ffmpeg already installed."
fi

# 2. Python virtual environment
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate

# 3. Python dependencies (includes yt-dlp)
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt --break-system-packages 2>/dev/null || pip install -r requirements.txt

echo ""
echo "=== Setup complete ==="
echo "Run the app with:"
echo "  source venv/bin/activate"
echo "  uvicorn main:app --reload --port 8000"
echo ""
echo "Then open http://localhost:8000 in your browser."
