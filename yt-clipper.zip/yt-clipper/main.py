"""
YouTube Auto-Clipper — Personal Use Tool
------------------------------------------
Paste a YouTube URL, it downloads the video, auto-detects scene changes,
cuts it into clips, and lets you download individual clips or all of them
as a ZIP.

Run with:
    uvicorn main:app --reload --port 8000

Requires yt-dlp and ffmpeg installed on the system (see setup.sh).
"""

import os
import re
import uuid
import zipfile
import subprocess
import shutil
from pathlib import Path
from typing import List, Tuple

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="YouTube Auto-Clipper")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).parent
CLIPS_DIR = BASE_DIR / "clips"
CLIPS_DIR.mkdir(exist_ok=True)

# In-memory job tracker (fine for personal/single-user use).
JOBS = {}


class ProcessRequest(BaseModel):
    url: str
    scene_threshold: float = 0.35   # lower = more clips, higher = fewer clips
    min_clip_seconds: float = 3.0   # discard clips shorter than this
    max_clip_seconds: float = 120.0  # force-split clips longer than this


def run(cmd: List[str], **kwargs) -> subprocess.CompletedProcess:
    """Run a subprocess command, raising a readable error on failure."""
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\n--- stderr ---\n{result.stderr[-4000:]}"
        )
    return result


def download_video(url: str, out_path: Path) -> Path:
    """Download the YouTube video with yt-dlp as a single mp4 file."""
    run([
        "yt-dlp",
        "-f", "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "--merge-output-format", "mp4",
        "--no-playlist",
        "-o", str(out_path),
        url,
    ])
    if not out_path.exists():
        # yt-dlp sometimes appends its own extension resolution; find it.
        candidates = list(out_path.parent.glob(f"{out_path.stem}*"))
        if candidates:
            candidates[0].rename(out_path)
        else:
            raise RuntimeError("Download finished but output file was not found.")
    return out_path


def get_duration(path: Path) -> float:
    """Get video duration in seconds via ffprobe."""
    result = run([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path),
    ])
    return float(result.stdout.strip())


def detect_scene_timestamps(path: Path, threshold: float) -> List[float]:
    """
    Run ffmpeg's scene-detection filter and parse the pts_time values
    out of the showinfo log. Returns a sorted list of cut-point timestamps
    (seconds), always including 0.0 as the first point.
    """
    result = subprocess.run(
        [
            "ffmpeg", "-i", str(path),
            "-vf", f"select='gt(scene,{threshold})',showinfo",
            "-f", "null", "-",
        ],
        capture_output=True, text=True,
    )
    # ffmpeg writes showinfo output to stderr regardless of success/fail exit code
    log = result.stderr

    timestamps = [0.0]
    for match in re.finditer(r"pts_time:([\d.]+)", log):
        t = float(match.group(1))
        if t - timestamps[-1] > 0.5:  # avoid near-duplicate cuts
            timestamps.append(t)

    return timestamps


def build_clip_ranges(
    timestamps: List[float],
    total_duration: float,
    min_len: float,
    max_len: float,
) -> List[Tuple[float, float]]:
    """
    Turn a list of cut-point timestamps into (start, end) ranges, merging
    any range that's too short into its neighbor, and force-splitting any
    range that's too long.
    """
    timestamps = sorted(set(timestamps))
    if timestamps[-1] < total_duration:
        timestamps.append(total_duration)

    raw_ranges = list(zip(timestamps[:-1], timestamps[1:]))

    # Merge short ranges forward into the next one
    merged: List[Tuple[float, float]] = []
    carry_start = None
    for start, end in raw_ranges:
        if carry_start is not None:
            start = carry_start
            carry_start = None
        if end - start < min_len:
            carry_start = start
            continue
        merged.append((start, end))
    if carry_start is not None and merged:
        last_start, _ = merged[-1]
        merged[-1] = (last_start, total_duration)
    elif carry_start is not None:
        merged.append((carry_start, total_duration))

    # Force-split ranges that are too long
    final: List[Tuple[float, float]] = []
    for start, end in merged:
        length = end - start
        if length <= max_len:
            final.append((start, end))
            continue
        n_pieces = int(length // max_len) + 1
        piece_len = length / n_pieces
        for i in range(n_pieces):
            final.append((start + i * piece_len, start + (i + 1) * piece_len))

    return final


def cut_clip(source: Path, start: float, end: float, out_path: Path) -> None:
    """Cut a single clip. Re-encodes to guarantee frame-accurate cuts."""
    run([
        "ffmpeg", "-y",
        "-ss", f"{start:.3f}",
        "-to", f"{end:.3f}",
        "-i", str(source),
        "-c:v", "libx264", "-c:a", "aac",
        "-preset", "veryfast",
        str(out_path),
    ])


def process_job(job_id: str, url: str, scene_threshold: float,
                 min_clip_seconds: float, max_clip_seconds: float) -> None:
    job_dir = CLIPS_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    JOBS[job_id] = {"status": "downloading", "clips": [], "error": None}

    try:
        source = job_dir / "source.mp4"
        download_video(url, source)

        JOBS[job_id]["status"] = "analyzing"
        duration = get_duration(source)
        timestamps = detect_scene_timestamps(source, scene_threshold)
        ranges = build_clip_ranges(timestamps, duration, min_clip_seconds, max_clip_seconds)

        JOBS[job_id]["status"] = "cutting"
        clip_names = []
        for i, (start, end) in enumerate(ranges):
            name = f"clip_{i+1:02d}.mp4"
            cut_clip(source, start, end, job_dir / name)
            clip_names.append({
                "filename": name,
                "start": round(start, 2),
                "end": round(end, 2),
                "duration": round(end - start, 2),
            })

        JOBS[job_id]["status"] = "done"
        JOBS[job_id]["clips"] = clip_names

    except Exception as e:
        JOBS[job_id]["status"] = "error"
        JOBS[job_id]["error"] = str(e)


@app.post("/process")
def process_video_endpoint(req: ProcessRequest, background_tasks: BackgroundTasks):
    if "youtube.com" not in req.url and "youtu.be" not in req.url:
        raise HTTPException(400, "Please provide a valid YouTube URL.")

    job_id = str(uuid.uuid4())[:8]
    background_tasks.add_task(
        process_job, job_id, req.url,
        req.scene_threshold, req.min_clip_seconds, req.max_clip_seconds,
    )
    return {"job_id": job_id, "status": "queued"}


@app.get("/status/{job_id}")
def get_status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found.")
    return {"job_id": job_id, **job}


@app.get("/clips/{job_id}/{filename}")
def get_clip(job_id: str, filename: str):
    path = CLIPS_DIR / job_id / filename
    if not path.exists():
        raise HTTPException(404, "Clip not found.")
    return FileResponse(path, filename=filename, media_type="video/mp4")


@app.get("/clips/{job_id}/zip/all")
def get_all_clips_zip(job_id: str):
    job_dir = CLIPS_DIR / job_id
    if not job_dir.exists():
        raise HTTPException(404, "Job not found.")

    zip_path = job_dir / "all_clips.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(job_dir.glob("clip_*.mp4")):
            zf.write(f, f.name)

    return FileResponse(zip_path, filename=f"clips_{job_id}.zip", media_type="application/zip")


@app.delete("/clips/{job_id}")
def delete_job(job_id: str):
    job_dir = CLIPS_DIR / job_id
    if job_dir.exists():
        shutil.rmtree(job_dir)
    JOBS.pop(job_id, None)
    return {"deleted": job_id}


# Serve the frontend
app.mount("/", StaticFiles(directory=str(BASE_DIR / "static"), html=True), name="static")
